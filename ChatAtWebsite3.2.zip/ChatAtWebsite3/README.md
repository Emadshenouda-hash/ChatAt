\# ChatAt.org – Bilingual Modern Website



\## Quick Start



1\. `npm install`

2\. `npm run dev`

3\. Open \[http://localhost:3000](http://localhost:3000)



\## Deploy to Netlify



\- Push this repo to GitHub

\- Connect to Netlify

\- Build command: `npm run build`

\- Publish directory: `.next`



\## Add your images to `public/images/logo.png` and `public/images/hero.jpg`.



